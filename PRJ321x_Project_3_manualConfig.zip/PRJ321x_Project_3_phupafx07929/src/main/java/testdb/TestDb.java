package testdb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.Resultset;

import context.DBContext;
import dao.AccountDao;
import dao.ListProductDao;
import model.Product;

/**
 * Servlet implementation class TestDb
 */
@WebServlet("/TestDb")
public class TestDb extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private Connection conn;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestDb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
		try {
			conn = DBContext.getConnection();
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	PrintWriter out = response.getWriter();
	
//	String query = "select count(*) as count from products";
//	try {
//		PreparedStatement stmt = conn.prepareStatement(query);
//		ResultSet rs = stmt.executeQuery();
//		
//		int count = 0;
//		if(rs.next()) {
//			count = rs.getInt("count");
//		}
//		
//		rs.close();
	
		int count = 0;
		
		List<Product> list;
		try {
			ListProductDao a = new ListProductDao();
			list = a.search("32gb","cellphone",0,6);
			count = a.getNumRecord();
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Product itemTest = null;
		
		try {
			itemTest = new ListProductDao().getProduct("1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Boolean test=null;
		try {
			test = new AccountDao().checkLogin("duongdt@fpt.com.vn", "123");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		out.println("<html> this is the number of records: ");
		out.println(count);
		out.println("<br/>");
		out.println(itemTest.getName());
		out.println("<br/>");
		out.println(test);

		out.println("</html>");
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
