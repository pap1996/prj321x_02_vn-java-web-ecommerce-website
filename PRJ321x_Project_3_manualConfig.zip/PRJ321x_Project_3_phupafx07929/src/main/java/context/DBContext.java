package context;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBContext {
	
	private static DataSource ds;
	
	private static Connection conn;
	
	private static DBContext instance;
	
	private DBContext() throws NamingException, SQLException {
		InitialContext initialContext = new InitialContext();
		
		Context env = (Context) initialContext.lookup("java:comp/env");
	
		ds = (DataSource) env.lookup("jdbc/shoppingdb");
		
		conn = ds.getConnection();
	}
	
	public static Connection getConnection() throws NamingException, SQLException {
	
		if (instance == null) {
			DBContext context = new DBContext();
		}
		
		return conn;
		
	}

}
