package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Cart {
	
	private List<Product> items;
	
	public Cart() {
		items = new ArrayList<>();
	}
	
	
	// add a new product to cart
	public void add(Product ci) {
		for(Product x: items) {
			if(ci.getID() == x.getID()) {
				x.setNumber(x.getNumber() + 1);
				return;
			}
		}
		
		
		Product newPd = new Product();
		
		newPd.setID(ci.getID());
		newPd.setName(ci.getName());
		newPd.setBrand(ci.getBrand());
		newPd.setDescription(ci.getDescription());
		newPd.setPrice(ci.getPrice());
		newPd.setSrc(ci.getSrc());
		newPd.setType(ci.getType());
		newPd.setNumber(1);
		items.add(newPd);
	}
	
	
	//minus the number of product in cart
		public void minus(Product ci) {
			for(Product x: items) {
				if(ci.getID() == x.getID()) {
					x.setNumber(x.getNumber() - 1);
					return;
				}
			}
		}
		
		
		public void remove(int id) {
			for (Product x: items) {
				if (x.getID() == id) {
					items.remove(x);
					return;
				}
			}
		}
		
		public double getAmount() {
			double s = 0;
			for (Product x:items) {
				s += x.getPrice() * x.getNumber();
			}
			
			return Math.round(s*100.0)/100.0;
		}
		
		public List<Product> getItems() {
			return items;
		}
		
		public Product getProductFromList(String id) {
			
			for (Product x: items) {
				if (x.getID() == Integer.parseInt(id)) {
					return x;
					
				}
			}
			
			return null;
		}

}
