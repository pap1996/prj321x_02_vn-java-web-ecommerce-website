package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.print.attribute.standard.PageRanges;

import org.apache.tomcat.jni.User;

import com.mysql.cj.Query;

import context.DBContext;
import model.Account;

public class AccountDao {
	
	private String message;
	
	
	public boolean checkLogin(String username, String password) throws NamingException, SQLException {
		
		int rowSelected = 0;
		
		Connection conn = DBContext.getConnection();
		
		String query = "SELECT count(*) from ACCOUNT where user_mail = ? and password = ?";
		
		PreparedStatement stmt = conn.prepareStatement(query);
		
		stmt.setString(1, username);
		stmt.setString(2, password);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			rowSelected = rs.getInt(1);
		}
		
		rs.close();
		return rowSelected == 1? true: false;
		
	}
	
	
	public boolean checkEmailExist(String username) throws NamingException, SQLException {
		
		int rowSelected = 0;
		
		Connection conn = DBContext.getConnection();
		
		String query = "SELECT count(*) from ACCOUNT where user_mail = ?";
		
		PreparedStatement stmt = conn.prepareStatement(query);
		
		stmt.setString(1, username);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			rowSelected = rs.getInt(1);
		}
		
		rs.close();
		return rowSelected == 1? true: false;
		
	}
	
	public void createNewAccount(Account acc) throws NamingException, SQLException {
		
		
		Connection conn = DBContext.getConnection();
		
		String sql = "insert into account (user_mail, password, user_name, user_address, user_phone, account_role) values (?, ?, ?, ?, ?, ? )";
		
		PreparedStatement stmt = conn.prepareStatement(sql);
		
		stmt.setString(1, acc.getUsr());
		stmt.setString(2, acc.getPwd());
		stmt.setString(3, acc.getName());
		stmt.setString(4, acc.getAddress());
		stmt.setString(5, acc.getPhone());
		stmt.setInt(6, 1);
		
		stmt.executeUpdate();
		stmt.close();
		
	}

}
