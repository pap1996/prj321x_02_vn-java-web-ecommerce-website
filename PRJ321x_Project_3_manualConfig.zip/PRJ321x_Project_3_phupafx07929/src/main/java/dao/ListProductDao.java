package dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import context.DBContext;
import model.Product;

public class ListProductDao {
	
	private int numRecord = 0;
	
	public int getNumRecord() {
		return this.numRecord;
	}

	public List<Product> search(String keyword) throws NamingException, SQLException {

		ArrayList<Product> item = new ArrayList<>();
		Connection conn = DBContext.getConnection();

		String query = "SELECT * FROM PRODUCTS WHERE PRODUCT_NAME LIKE ?";

		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setString(1, "%" + keyword + "%");
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Product pd = new Product();
			pd.setID(rs.getInt(1));
			pd.setName(rs.getString(2));
			pd.setDescription(rs.getString(3));
			pd.setPrice(rs.getFloat(4));
			pd.setSrc(rs.getString(5));
			pd.setType(rs.getString(6));
			pd.setBrand(rs.getString(7));

			item.add(pd);
		}

		rs.close();

//		rs = stmt.executeQuery("SELECT FOUND_ROWS()");
//		if(rs.next()) {
//			numRecord = rs.getInt(1);
//		}
		
		if (item != null) {
			this.numRecord = item.size();
		}
		
		
		conn.close();

		return item;
	}

	public List<Product> search(String keyword, String cate, int offset, int numRecord) throws NamingException, SQLException {

		ArrayList<Product> item = new ArrayList<>();
		Connection conn = DBContext.getConnection();

		String query = "SELECT SQL_CALC_FOUND_ROWS * FROM PRODUCTS WHERE PRODUCT_NAME LIKE ? and PRODUCT_TYPE= ? LIMIT ? , ?";

		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setString(1, "%" + keyword + "%");
		stmt.setString(2, ""+cate);
		stmt.setInt(3, offset);
		stmt.setInt(4, numRecord);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Product pd = new Product();
			pd.setID(rs.getInt(1));
			pd.setName(rs.getString(2));
			pd.setDescription(rs.getString(3));
			pd.setPrice(rs.getFloat(4));
			pd.setSrc(rs.getString(5));
			pd.setType(rs.getString(6));
			pd.setBrand(rs.getString(7));

			item.add(pd);
		}

		rs.close();
		
		
		query = "SELECT count(*) FROM PRODUCTS WHERE PRODUCT_NAME LIKE ? and PRODUCT_TYPE= ?";
		
		stmt = conn.prepareStatement("SELECT count(*) FROM PRODUCTS WHERE PRODUCT_NAME LIKE ? and PRODUCT_TYPE= ? ");
		stmt.setString(1, "%" + keyword + "%");
		stmt.setString(2, ""+cate);
		rs = stmt.executeQuery();
		if(rs.next()) {
			this.numRecord = rs.getInt(1);
		}
		
		
		
//		if (item != null) {
//			this.numRecord = item.size();
//		}
//		
		rs.close();

		conn.close();

		return item;
	}

	public Product getProduct(String ID) throws Exception {

		Product searchItem = new Product();

		Connection conn = DBContext.getConnection();

		String query = "SELECT * FROM PRODUCTS WHERE PRODUCT_ID = ?";

		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setString(1, ID);

		ResultSet rs = stmt.executeQuery();

		if (rs.next()) {
			searchItem.setID(rs.getInt(1));
			searchItem.setName(rs.getString(2));
			searchItem.setDescription(rs.getString(3));
			searchItem.setPrice(rs.getFloat(4));
			searchItem.setSrc(rs.getString(5));
			searchItem.setType(rs.getString(6));
			searchItem.setBrand(rs.getString(7));
		}

		return searchItem;

	}

}
