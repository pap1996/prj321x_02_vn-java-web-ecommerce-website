package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.User;

import com.mysql.cj.Session;

import dao.AccountDao;
import model.Account;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		String action = request.getParameter("actionInRegister");
		
		
		
		if(action.equals("register")) {
			try {
				register(request, response);
			} catch (ServletException | IOException | NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 

	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, NamingException, SQLException {
		// TODO Auto-generated method stub
		
		String email = request.getParameter("username");
		String password = request.getParameter("password");
		String retypePassword = request.getParameter("repassword");
		String fullName = request.getParameter("fullname");
		String address = request.getParameter("address");
		String phonenumber = request.getParameter("phonenumber");
		
		
		String regexMail = "^[A-Z0-9_a-z]+@[A-Z0-9\\.a-z]+\\.[A-Za-z]{2,6}";
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";
		
		Account newUser = new Account();
		
		newUser.setUsr(email);
		newUser.setPwd(password);
		newUser.setName(fullName);
		newUser.setAddress(address);
		newUser.setPhone(phonenumber);
		
		AccountDao accDao = new AccountDao();
		
		if (!email.matches(regexMail)) {
			request.setAttribute("error", "Invalid email");
			
			newUser.setUsr("");
			
			request.setAttribute("userInput", newUser);
			request.getRequestDispatcher("register.jsp").forward(request, response);
		} else if (accDao.checkEmailExist(newUser.getUsr())) {
			request.setAttribute("error", "The email exists in systems, please user another email");
			
			newUser.setUsr("");
			request.setAttribute("userInput", newUser);
			request.getRequestDispatcher("register.jsp").forward(request, response);
		} else if (!password.matches(regex) | !password.equals(retypePassword)){
			request.setAttribute("error", "Invalid password");
			
			newUser.setPwd("");
			request.setAttribute("userInput", newUser);
			request.getRequestDispatcher("register.jsp").forward(request, response);
		} else {
			// Insert into Data base
			
			new AccountDao().createNewAccount(newUser);
			request.getSession(true).invalidate();
			
			HttpSession session = request.getSession();
			session.setAttribute("user", newUser);
			session.setAttribute("successRegister", "You have successfully registered a new account, log in with it!");
			
			response.sendRedirect("login.jsp");
		
		}
		
	


		
//		if (accDao.checkEmailExist(newUser.getUsr())) {
//			request.setAttribute("error", "The email exists in systems, please user another email");
//		}
		
		
		
	}

}
