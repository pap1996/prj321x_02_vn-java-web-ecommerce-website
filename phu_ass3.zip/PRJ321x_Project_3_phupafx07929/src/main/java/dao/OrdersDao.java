package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import context.DBContext;
import model.Cart;
import model.Orders;
import model.Product;
import model.ProductOrders;

public class OrdersDao {

	public void insertOrder(Orders o, Cart c) throws NamingException, SQLException {
		
		Connection conn =  DBContext.getConnection();
		
		String sql = "insert into orders (user_mail, order_status, order_date, order_discount_code,order_address) values (?,?,?,?,?)";
		
		PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		
		stmt.setString(1, o.getUserMail());
		stmt.setInt(2, o.getStatus());
		stmt.setDate(3, new Date(o.getOrderDate().getTime()));
		stmt.setString(4, o.getDiscount());
		stmt.setString(5, o.getAddress());
		
		stmt.executeUpdate();
		
		try (ResultSet rs = stmt.getGeneratedKeys()) {
			
			while (rs.next()) {
				
				o.setOrderId(rs.getLong(1));
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		List<ProductOrders> pl = new ArrayList<>();
		
		for(Product pd: c.getItems()) {
			
			ProductOrders poItem = new ProductOrders();
			
			poItem.setOrderId(o.getOrderId());
			poItem.setAmountProduct(pd.getNumber());
			poItem.setNameProduct(pd.getName());
			poItem.setProductId(pd.getID());
			
			pl.add(poItem);
			
			sql = "insert into orders_detail (order_id, product_id, amount_product, price_product) values (?,?,?,?) ";
			
			stmt = conn.prepareStatement(sql);
			
			stmt.setLong(1, poItem.getOrderId());
			stmt.setInt(2, poItem.getProductId());
			stmt.setInt(3, poItem.getAmountProduct());
			stmt.setFloat(4, pd.getAmount());
			
			stmt.executeUpdate();
			
		}
		
		o.setLp(pl);
		
		stmt.close();
		
	}
}
