package model;

public class ProductOrders {
	
	private long orderId;
	private int productId;
	private int amountProduct; // quantity
	private String nameProduct;
	
	
	
	
	public ProductOrders(int orderId, int productId, int amountProduct, String nameProduct) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.amountProduct = amountProduct;
		this.nameProduct = nameProduct;
	}
	
	public ProductOrders() {
		// TODO Auto-generated constructor stub
	}

	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long l) {
		this.orderId = l;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getAmountProduct() {
		return amountProduct;
	}
	public void setAmountProduct(int amountProduct) {
		this.amountProduct = amountProduct;
	}
	public String getNameProduct() {
		return nameProduct;
	}
	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}
	
	

}
