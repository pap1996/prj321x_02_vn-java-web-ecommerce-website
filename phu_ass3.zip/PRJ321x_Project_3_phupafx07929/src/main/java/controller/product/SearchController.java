package controller.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ListProductDao;
import model.Product;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/SearchController")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html;charset=UTF-8");
		
		
		String category = request.getParameter("cate") != null ? request.getParameter("cate") : "cellphone";
		String searchKey = request.getParameter("searchKey") != null ? request.getParameter("searchKey") : "";
		
		int page = request.getParameter("page") != null ? Integer.parseInt(request.getParameter("page") ) : 1;
		int recordPerPage = 6;
		try {
			
			ListProductDao listProductDao = new ListProductDao();
			List<Product> ls = listProductDao.search(searchKey, category, (page-1)*recordPerPage, recordPerPage);
			int numOfPage = listProductDao.getNumRecord() % recordPerPage > 0 ? listProductDao.getNumRecord() / recordPerPage + 1 : 
				listProductDao.getNumRecord() / recordPerPage;
			request.setAttribute("products", ls);
			request.setAttribute("cate", category);
			request.setAttribute("currentPage", page);
			request.setAttribute("numOfPage", numOfPage);
//			request.setAttribute(searchKey, category);
			request.setAttribute("searchKey", searchKey);
			request.getRequestDispatcher("home.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
