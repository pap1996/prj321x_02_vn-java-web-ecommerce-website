package com.phuphana;

import java.util.Collection;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.phuphana.data.ProductsRepository;
import com.phuphana.domain.Products;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class ProductsRepositoryTest {

	@Autowired
	private ProductsRepository productsRepository;
	
	
	@Test
	public void findAllTest() {
		int size = ((Collection<Products>) productsRepository.findAll()).size();
		
		Assertions.assertEquals(10, size);
	}
	
	@Test
	public void findWithParamsTest() {
		
		Pageable pageable = PageRequest.of(1, 3);
		
		Page<Products> result = productsRepository.findWithParams(pageable, "cellphone", "%128%");
		
		Assertions.assertEquals(2, result.getTotalElements());
		
	}
	
	
	
	// Immutable
	@Test
	public void testImmutable() {
		
		Products p1 = productsRepository.findById((long) 1).orElse(null);
		Products p2 = productsRepository.findById((long) 1).orElse(null);

		Assertions.assertEquals(p1,p2);
		
		p1.setProductId(3434);
		Assertions.assertEquals(1, p2.getProductId());
	}
}
