package com.phuphana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj321xProject3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
