package com.phuphana;

import java.util.Collection;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.JdbcTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.phuphana.data.AccountRepository;
import com.phuphana.domain.Account;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class AccountRepositoryTest {
	

	@Autowired
	private AccountRepository accountRepository;
	
	@Test
	public void countAccountAll() {
		
	 int size = ((Collection<com.phuphana.domain.Account>)	accountRepository.findAll()).size();
	 
	 Assertions.assertEquals(8, size);
	}
	
	@Test
	public void findAccountByUserMailAndPasswordTest() {
		
		
		Account account = accountRepository.findAccountByUserMailAndPassword("a@gmail.com", "CYWW2mXNEuBgx2n").orElse(null);
		
		Assertions.assertEquals("a@gmail.com", account.getUserMail());
		
	}

}
