package com.phuphana;

import java.util.Collection;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.phuphana.data.OrdersRepository;
import com.phuphana.data.ProductsOrdersRepository;
import com.phuphana.domain.Orders;
import com.phuphana.domain.ProductsOrders;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class OrdersRepositoryTest {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	private ProductsOrdersRepository productsOrdersRepository;
	
	@Test
	public void findAllTest() {
		
		
		
		 int size = ((Collection<Orders>)	ordersRepository.findAll()).size();
		 
		 Assertions.assertEquals(7, size);
		 
	}
	
	@Test
	public void findAllProductOrderTest() {
		
		
		 int size = ((Collection<ProductsOrders>)	productsOrdersRepository.findAll()).size();

		 Assertions.assertEquals(14, size);
		 
		 

	}
	
	
//	@Test
//	public void saveOrderTest() {
//		Orders order = new Orders();
//		order.setUserMail("hello test");
//		order.setOrderAddress("test Addr");
//		order.setOrderDate(new Date());
//		order.setOrderDiscountCode("test coupon");
//		order.setOrderStatus("pending");
//		
//		
//		
//		
//		ordersRepository.save(null);
//	}
//	

}
