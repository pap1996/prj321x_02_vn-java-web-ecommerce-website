package com.phuphana.domain;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.phuphana.data.AccountRepository;

@Component
public class AccountValidator implements Validator {

	@Autowired
	private AccountRepository accountRepository;
	
	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Account.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
		Account account = (Account) target;
		Optional<Account> rs = accountRepository.findAccountByUserMailAndPassword(account.getUserMail(), account.getPassword());
		
		if (rs.isEmpty()) {
			errors.rejectValue("password" ,"nonexist", "The user mail or password is incorrect");
		}
		
		
	}

}
