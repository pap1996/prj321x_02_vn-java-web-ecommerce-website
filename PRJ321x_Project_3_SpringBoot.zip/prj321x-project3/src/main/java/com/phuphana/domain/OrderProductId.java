package com.phuphana.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Embeddable
public class OrderProductId implements Serializable {
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Products products;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Orders orders;

}
