package com.phuphana.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;


@Data
public class Cart {

	private Map<Products, Integer> items;
	
	private BigDecimal cartAmount = BigDecimal.ZERO;

	public Cart() {
		// TODO Auto-generated constructor stub
		items = new HashMap<Products, Integer>();
	}

	public void addProduct(Products product) {
		// TODO Auto-generated method stub
		int number = items.getOrDefault(product, 0);
		
			items.put(product, number+1); // be careful with ++ from Integer class or any Immutable class
			System.out.println("Method add: " + product.getProductPrice());
			System.out.println("Method get: " + cartAmount);
			cartAmount = cartAmount.add(product.getProductPrice()); // !important BigDecimal is immuatble -> reassign
		
			System.out.println("Method get After add: " + cartAmount);
			System.out.println("Quantity after add" + items.getOrDefault(product, 0));

	}
	
	public BigDecimal getKeyAmount(Products key) {
		
		return key.getProductPrice().multiply(new BigDecimal(items.getOrDefault(key, 0)));
	}

	public void minusProduct(Products product) {
		// TODO Auto-generated method stub
		int number = items.getOrDefault(product, 0);
		
		if (number - 1 <=0) {
			cartAmount = cartAmount.add(product.getProductPrice().negate());
			items.remove(product);
			return;
		}
		
	 	items.put(product, number-1); // be careful with ++ from Integer class or any Immutable class
		System.out.println("Method add: " + product.getProductPrice());
		System.out.println("Method get: " + cartAmount);
		cartAmount = cartAmount.add(product.getProductPrice().negate()); // !important BigDecimal is immuatble -> reassign
	
		System.out.println("Method get After add: " + cartAmount);
		System.out.println("Quantity after add" + items.getOrDefault(product, 0));
	}

	public void removeProduct(Products product) {
		// TODO Auto-generated method stub
		 
		int number = items.getOrDefault(product, 0);
		System.out.println("Method get before Remove: " + cartAmount);
		cartAmount = cartAmount.add(product.getProductPrice().multiply(new BigDecimal(number)).negate());
		
		
		
		System.out.println("Method get after Remove: " + cartAmount);
		items.remove(product);
		
	}
	
}
