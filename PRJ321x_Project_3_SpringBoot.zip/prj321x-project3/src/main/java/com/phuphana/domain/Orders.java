package com.phuphana.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Generated;

import lombok.Data;


@Data
@Entity
public class Orders {

	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private long orderId;
	private String userMail;
	private String orderStatus;
	private Date orderDate;
	private String orderDiscountCode;
	private String orderAddress;
	
	@OneToMany(mappedBy = "compositeKey.orders", cascade = CascadeType.ALL)
	private List<ProductsOrders> productsOrders;
}
