package com.phuphana.domain;

import java.math.BigDecimal;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import lombok.Data;


@Data
@Entity
@Table(name = "ORDERS_DETAIL")
@AssociationOverrides({
		@AssociationOverride(name= "compositeKey.orders",
		joinColumns=@JoinColumn(name="ORDER_ID")),
		@AssociationOverride(name= "compositeKey.products",
		joinColumns=@JoinColumn(name="PRODUCT_ID"))
})
public class ProductsOrders {
	
	@EmbeddedId
	private OrderProductId compositeKey = new OrderProductId();
	
	private int amountProduct;
	private BigDecimal priceProduct;

}
