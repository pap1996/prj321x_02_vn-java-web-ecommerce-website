package com.phuphana.domain;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.aspectj.weaver.tools.Trace;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)  // cach de lay 1 muttable lam key
public class Products {

	
	@Id
	@EqualsAndHashCode.Include
	private long productId;
	private String productName;
	private String productDes;
	private BigDecimal productPrice;
	private String productImgSource;
	private String productType;
	private String productBrand;
	
	@OneToMany(mappedBy = "compositeKey.products", cascade = CascadeType.ALL)
	private List<ProductsOrders> productsOrders;
	
	public enum ProductType {
		cellphone, book
	}
	
	
}
