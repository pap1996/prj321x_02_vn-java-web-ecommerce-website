package com.phuphana.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity
public class Account {
	
	@Id
	@NotBlank(message = "Email must not be empty or blank for login")
	@NotNull(message = "Email must not be empty for login")
	@Email(message = "Email is invalid")
	private String userMail;
	
	@Size(min = 8,message = "Password must be 8 characters long at least")
	private String password;
	
	private int accountRole = 1;
	private String userName;
	private String userAddress;
	private String userPhone;
	
	
	
	public enum Role {
		ADMIN 
	}
	
	public Account(String userMail, String password) {
		this.userMail = userMail;
		this.password = password;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}

}
