package com.phuphana.data;

import org.springframework.data.repository.CrudRepository;

import com.phuphana.domain.Orders;

public interface OrdersRepository extends CrudRepository<Orders, Long> {
}
