package com.phuphana.data;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.phuphana.domain.Products;

public interface ProductsRepository extends CrudRepository<Products, Long>, PagingAndSortingRepository<Products, Long> {

	
	@Query(value = "SELECT * FROM PRODUCTS WHERE PRODUCT_TYPE=:cate AND PRODUCT_NAME LIKE :searchKey",
			nativeQuery = true)
	Page<Products> findWithParams(Pageable pageable, @Param("cate") String cate, @Param("searchKey") String searchKey);
}
