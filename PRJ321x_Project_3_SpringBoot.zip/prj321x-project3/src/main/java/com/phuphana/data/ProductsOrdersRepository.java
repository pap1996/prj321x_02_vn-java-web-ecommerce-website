package com.phuphana.data;

import org.springframework.data.repository.CrudRepository;

import com.phuphana.domain.OrderProductId;
import com.phuphana.domain.ProductsOrders;

public interface ProductsOrdersRepository extends CrudRepository<ProductsOrders, OrderProductId> {

}
