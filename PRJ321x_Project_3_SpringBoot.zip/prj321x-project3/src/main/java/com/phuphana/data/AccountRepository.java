package com.phuphana.data;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.phuphana.domain.Account;

public interface AccountRepository extends CrudRepository<Account, String> {
	
	
	Optional<Account> findAccountByUserMailAndPassword(String userMail, String password);

}
