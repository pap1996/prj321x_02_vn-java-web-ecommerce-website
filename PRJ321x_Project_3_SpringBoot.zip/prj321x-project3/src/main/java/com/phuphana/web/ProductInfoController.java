package com.phuphana.web;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.phuphana.data.ProductsRepository;
import com.phuphana.domain.Products;

@Controller
@RequestMapping(value = "/productInfo")
public class ProductInfoController {
	
	
	@Autowired
	ProductsRepository productsRepository;
	
	@GetMapping(value = "/{id}")
	public String productInfo (@PathVariable(name = "id") long id, Model model) {
		
		Products product = productsRepository.findById(id).orElse(new Products());
		model.addAttribute("product", product);
		
		
		return "infoProduct";
		
	}

}
