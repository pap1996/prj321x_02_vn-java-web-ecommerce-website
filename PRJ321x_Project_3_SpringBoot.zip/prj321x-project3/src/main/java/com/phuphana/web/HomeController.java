package com.phuphana.web;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.phuphana.data.ProductsRepository;
import com.phuphana.domain.Products;

@Controller
@RequestMapping({"/", "/home"})
public class HomeController {
	
	@Autowired
	private ProductsRepository productsRepository;
	
	
//	@GetMapping(params = {})
//	public String home(Model model) {
//		
//		
//		PageRequest pageable = PageRequest.of(0, 6);
//		
//		List<Products> products;
//		Page<Products> result = productsRepository.findAll(pageable);
//		
//		if (!result.isEmpty()) {
//			products = result.getContent();
//		} else {
//			products = new ArrayList<Products>();
//		}
//		
//		model.addAttribute("products", products);
//		model.addAttribute("numOfPage", result.getTotalPages());
//		model.addAttribute("currentPage", result.getNumber());
//		
//		System.out.println(products.size());
//		
//		return "home";
//	}
//	

	@GetMapping
	public String home1(Model model, @RequestParam(value = "page", required =  false, defaultValue = "1") int page
			, @RequestParam(value = "cate", required = false, defaultValue = "cellphone") String cate
			, @RequestParam(value = "searchKey", required = false, defaultValue = "") String searchKey) {
		
	
		searchKey = "%" + searchKey + "%";
		PageRequest pageable = PageRequest.of(page-1, 6);
		
		List<Products> products;
		Page<Products> result = productsRepository.findWithParams(pageable, cate, searchKey);
				
		if (!result.isEmpty()) {
			products = result.getContent();
		} else {
			products = new ArrayList<Products>();
		}
		
		model.addAttribute("products", products);
		model.addAttribute("numOfPage", result.getTotalPages());
		model.addAttribute("currentPage", result.getNumber()+1);
		
		System.out.println(products.size());
		
		return "home";
	}


}
