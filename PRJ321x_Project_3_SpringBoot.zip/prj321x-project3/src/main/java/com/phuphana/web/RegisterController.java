package com.phuphana.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.phuphana.data.AccountRepository;
import com.phuphana.domain.Account;

@Controller
public class RegisterController {
	
	@Autowired
	private AccountRepository accountRepository;
	
	
	@ModelAttribute("accountNew")
	public Account initAccount() {
		return new Account();
	}
	
	@GetMapping("/register")
	public String registerGet() {
		return "register";
	}
	
	@PostMapping("/register")
	public String registerPost(@Valid @ModelAttribute("accountNew") Account account, Errors errors,
			@RequestParam(value = "repassword", defaultValue = "") String repass,
			RedirectAttributes redirectAttributes,
			Model model
			) {
		
		if (errors.hasErrors()) {
			
			System.out.println(errors.getAllErrors().get(0).getDefaultMessage());
			return "register";
		}
		
		if (!repass.equalsIgnoreCase(account.getPassword())) {
			errors.rejectValue("password", "repassword", "Please retype the same password");
			System.out.println(errors.getAllErrors().get(0).getDefaultMessage());
			return "register";
		}
		
		if (accountRepository.findById(account.getUserMail()).isPresent()) {
			errors.rejectValue("userMail", "usermailExist", "The email is already existing");
			System.out.println(errors.getAllErrors().get(0).getDefaultMessage());
			return "register";
		}
		
		accountRepository.save(account);
		
		redirectAttributes.addFlashAttribute("account", account);
		redirectAttributes.addFlashAttribute("successRegister", "Register successfully, login to use");
		
		return "redirect:/login";
	}

}
