package com.phuphana.web;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.phuphana.data.AccountRepository;
import com.phuphana.domain.Account;
import com.phuphana.domain.AccountValidator;

@Controller
@SessionAttributes("account")
public class LoginLogoutController {
	
	
	@Autowired
	private AccountValidator accountValidator;
	
//	@InitBinder
//	public void bind(WebDataBinder webDataBinder) {
//		webDataBinder.addValidators(accountValidator);
//	}
	
	@Autowired
	private AccountRepository accountRepository;
	
	@ModelAttribute("account")
	public Account newAccount() {
		return new Account();
	}
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
	
	
	@GetMapping("/logout")
	public String logout(SessionStatus status) {
		
		status.setComplete();
		
		return "redirect:/home";
	}
	
	@PostMapping("/login")
	public String loginPost(Model model, @Valid Account account, Errors errors,
			@RequestParam(value =  "remember", defaultValue = "" ) String remember,
			SessionStatus sessionStatus) {
		
		if (errors.hasErrors()) {
			System.out.println("Has error : " + errors.getErrorCount() + errors.getAllErrors().get(0).getDefaultMessage());
			return "login";
		}
		
		accountValidator.validate(account, errors);
		
		if (errors.hasErrors()) {
			System.out.println("Has error : " + errors.getErrorCount() + errors.getAllErrors().get(0).getDefaultMessage());
			return "login";
		};
		
		model.addAttribute("account", accountRepository.findById(account.getUserMail()).get());
		
		if (!remember.equals("checkedValue")) {
			sessionStatus.setComplete();
		}
		
		return "admin/index";
	}

}
