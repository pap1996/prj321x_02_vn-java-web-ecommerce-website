package com.phuphana.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.phuphana.data.OrdersRepository;
import com.phuphana.data.ProductsOrdersRepository;
import com.phuphana.data.ProductsRepository;
import com.phuphana.domain.Cart;
import com.phuphana.domain.Orders;
import com.phuphana.domain.Products;
import com.phuphana.domain.ProductsOrders;


@Controller
@RequestMapping(value = "/cart")
@SessionAttributes("cart")
public class AddToCartController {
	
	@Autowired
	private ProductsRepository productsRepository;
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	private ProductsOrdersRepository productsOrdersRepository;
	
	@ModelAttribute(name="cart")
	public Cart newCart() {
		return new Cart();
	}
	
	
	@GetMapping
	public String addToCart(Cart cart,
			@RequestParam("id") long id,
			@RequestParam("action") String action) {
		
		Products product = productsRepository.findById(id).orElse(null);
		switch (action) {
		case "add":
			cart.addProduct(product);
			break;
		case "minus":
			cart.minusProduct(product);
			break;
		case "remove":
			cart.removeProduct(product);
			break;
		default:
			break;
		}
		
		
		System.out.println("Cart amount: " + cart.getCartAmount());
		
		return "cart";
	}
	
	
	@PostMapping
	public String saveOrder(Cart cart, SessionStatus sessionStatus,
			@RequestParam("customerAddress") String address,
			@RequestParam("customerName") String name,
			@RequestParam("coupon") String coupon) {
		
		Orders orders = new Orders();
		orders.setOrderAddress(address);
		orders.setUserMail(coupon);
		orders.setOrderDate(new Date());
		orders.setOrderDiscountCode(coupon);
		orders.setOrderStatus("1");
		
		List<ProductsOrders> list = new ArrayList<ProductsOrders>();
		
		for (Products p : cart.getItems().keySet()) {
			ProductsOrders productsOrders = new ProductsOrders();
			
			productsOrders.getCompositeKey().setOrders(orders);
			productsOrders.getCompositeKey().setProducts(p);
			
			productsOrders.setPriceProduct(p.getProductPrice());
			productsOrders.setAmountProduct(cart.getItems().get(p));
			
			list.add(productsOrders);
		}
		
		orders.setProductsOrders(list);
		
	    ordersRepository.save(orders);
	    
	    sessionStatus.setComplete();
	    
	    return "redirect:/home";
	    
		
	}

}
