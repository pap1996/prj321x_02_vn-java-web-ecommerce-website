package com.phuphana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj321xProject3Application {

	public static void main(String[] args) {
		SpringApplication.run(Prj321xProject3Application.class, args);
	}

}
